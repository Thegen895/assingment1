set.seed(123)

generate_workers <- function(n) {
  ids <- 1:n
  names <- paste0("Worker_", ids)
  genders <- sample(c("male", "female"), n, replace=TRUE)
  salaries <- sample(7000:30000, n, replace=TRUE)
  data.frame(id=ids, name=names, gender=genders, salary=salaries, stringsAsFactors=FALSE)
}

generate_payment_slips <- function(workers) {
  slips <- workers
  slips$level <- "N/A"
  for(i in 1:nrow(workers)) {
    tryCatch({
      if (workers$salary[i] > 10000 & workers$salary[i] < 20000) {
        slips$level[i] <- "A1"
      }
      if (workers$salary[i] > 7500 & workers$salary[i] < 30000 & workers$gender[i] == "female") {
        slips$level[i] <- "A5-F"
      }
    }, error=function(e){
      cat(paste("Error generating slip for Worker ID", workers$id[i], ":", e$message, "\n"))
    })
  }
  slips
}

workers <- generate_workers(400)
payment_slips <- generate_payment_slips(workers)
print(payment_slips)