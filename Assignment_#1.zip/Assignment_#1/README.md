# Weekly Payments Program

This repository contains a Python and R implementation for generating weekly payment slips for 400 workers. 

## Files

- `weekly_payments.py` — Python program
- `weekly_payments.R` — R program
- `README.md` — Instructions

## How to Run

### Python

1. Make sure you have Python 3 installed.
2. Run the program:
   ```
   python weekly_payments.py
   ```
   This will output a list of payment slips for 400 workers.

### R

1. Make sure you have R installed.
2. Run the program in R:
   ```R
   source("weekly_payments.R")
   ```
   This will print a data frame of payment slips for 400 workers.

## Logic

- 400 workers are created with random names, gender, and salaries.
- Payment slip generation uses these rules:
  - If salary is between $10,000 and $20,000, level is "A1".
  - If salary is between $7,500 and $30,000 **and** gender is female, level is "A5-F".
  - If both conditions met, the last one applies.
- Exception handling included for robustness.

## Submission

- Download all files, zip them, and upload to your GitHub repository.