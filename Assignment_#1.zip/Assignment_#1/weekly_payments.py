import random

def generate_workers(n):
    workers = []
    for i in range(n):
        worker = {
            "id": i + 1,
            "name": f"Worker_{i+1}",
            "gender": random.choice(["male", "female"]),
            "salary": random.randint(7000, 30000)
        }
        workers.append(worker)
    return workers

def generate_payment_slips(workers):
    slips = []
    for worker in workers:
        try:
            level = ""
            if 10000 < worker["salary"] < 20000:
                level = "A1"
            if 7500 < worker["salary"] < 30000 and worker["gender"] == "female":
                level = "A5-F"
            slip = {
                "id": worker["id"],
                "name": worker["name"],
                "gender": worker["gender"],
                "salary": worker["salary"],
                "level": level if level else "N/A"
            }
            slips.append(slip)
        except Exception as e:
            print(f"Error generating slip for Worker ID {worker['id']}: {e}")
    return slips

if __name__ == "__main__":
    workers = generate_workers(400)
    payment_slips = generate_payment_slips(workers)
    for slip in payment_slips:
        print(f"ID: {slip['id']}, Name: {slip['name']}, Gender: {slip['gender']}, Salary: ${slip['salary']}, Level: {slip['level']}")